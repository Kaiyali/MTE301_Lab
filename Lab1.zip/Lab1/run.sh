#!/bin/bash

echo "Clean"s
make clean

echo "Pre-Lab"
make lab1

echo "Run-Lab"
./lab1
