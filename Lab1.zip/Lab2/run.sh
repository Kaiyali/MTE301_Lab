#!/bin/bash

echo "Clean"s
make clean

echo "Pre-Lab"
make lab2

echo "Run-Lab"
./lab2
